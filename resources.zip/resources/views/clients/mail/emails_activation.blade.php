<p>Xin chào,</p>
<p>Vui lòng nhấn vào liên kết dưới đây để kích hoạt tài khoản của bạn ở website Travela:</p>
<button>
    <a href="{{ $link }}">Kích hoạt tài khoản</a>
</button>
<p>Trân trọng,<br>Nguyễn Minh Diện.</p>
